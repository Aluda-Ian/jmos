<?php $__env->startSection('content'); ?>
  <div class="headline">New Task Assigned to You</div>
  <p class="body-text">
    Hello <strong><?php echo e($assigneeName ?? 'Team Member'); ?></strong>,<br>
    You have been assigned a new task in the <strong>JMOS</strong> workflow.
  </p>

  <div class="info-card">
    <div class="info-row">
      <span class="info-label">Task Title</span>
      <span class="info-val"><?php echo e($taskTitle ?? 'Video Editing & Grade'); ?></span>
    </div>
    <div class="info-row">
      <span class="info-label">Project / Client</span>
      <span class="info-val"><?php echo e($projectName ?? 'General Production'); ?></span>
    </div>
    <div class="info-row">
      <span class="info-label">Initial Stage</span>
      <span class="info-val"><span class="badge badge-amber"><?php echo e(ucfirst($stage ?? 'To do')); ?></span></span>
    </div>
    <?php if(!empty($deadline)): ?>
    <div class="info-row">
      <span class="info-label">Target Deadline</span>
      <span class="info-val" style="color:#C52523"><?php echo e($deadline); ?></span>
    </div>
    <?php endif; ?>
    <div class="info-row">
      <span class="info-label">Assigned By</span>
      <span class="info-val"><?php echo e($assignedBy ?? 'Production Lead'); ?></span>
    </div>
  </div>

  <p class="body-text" style="font-size:13.5px;color:#6E6763">
    Please log in to your JMOS workspace to review the creative brief, access project assets, and advance the task stage when work begins.
  </p>

  <div style="text-align:center;margin:24px 0 10px">
    <a href="<?php echo e(url('/')); ?>" class="btn-action">Open Task in JMOS &rarr;</a>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('emails.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Brands\Jeota Media\jmos\resources\views/emails/task-assigned.blade.php ENDPATH**/ ?>