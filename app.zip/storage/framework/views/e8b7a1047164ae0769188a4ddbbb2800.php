<!-- ==========================================================================
     JMOS — View: People (Team & Access Management)
     ========================================================================== -->
<section class="view" data-view="people" hidden data-perm="owner finance manager">
  <div class="page-head">
    <div>
      <h1 class="pt">People</h1>
      <p>Your team, their access level, and how they're paid.</p>
    </div>
    <div class="head-actions">
      <button type="button" class="btn primary" id="addUserBtn" onclick="openModal('userModal')" data-modal-open="userModal">
        <svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>Add person
      </button>
    </div>
  </div>

  <div class="tablecard">
    <div class="tablewrap">
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Role</th>
            <th>Access</th>
            <th>Type</th>
            <th>Pay</th>
            <th>Login</th>
            <th></th>
          </tr>
        </thead>
        <tbody id="peopleBody"></tbody>
      </table>
    </div>
  </div>
</section>
<?php /**PATH G:\Brands\Jeota Media\jmos\resources\views/pages/people.blade.php ENDPATH**/ ?>